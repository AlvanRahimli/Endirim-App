﻿using Dendi.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Dendi.Controllers
{    
    // DONE ---------->
    public class ProductsController : ApiController
    {        
        public SqlConnection connection = new SqlConnection(@"Server=den1.mssql8.gear.host;Database=dendi;Uid=dendi;Pwd=Be1W!dsz0_f6;");
        
        // READY ---------->
        [HttpGet]
        public IHttpActionResult ProdByParts([FromUri]int rn)
        {
            // READY
            var QueryString = "SELECT ProductsTable.ID, UserID, Name, Shop, Price, Discount, AdditionTime, Username " +
                "FROM ProductsTable, UsersTable Where ProductsTable.UserID = UsersTable.ID " +
                $"ORDER BY ProductsTable.ID OFFSET {rn} ROWS FETCH NEXT 20 ROWS ONLY";
            
            IList<DiscountedProduct> discountedProducts = new List<DiscountedProduct>();
            connection.Open();
            using(var command = new SqlCommand(QueryString, connection))
            {
                using(var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        discountedProducts.Add(new DiscountedProduct()
                        {
                            ID = Convert.ToInt32(reader["ID"]),
                            UserID = Convert.ToInt32(reader["UserID"]),
                            Name = reader["Name"].ToString(),
                            Shop = reader["Shop"].ToString(),
                            Price = Convert.ToInt32(reader["Price"]),
                            Discount = Convert.ToDecimal(reader["Discount"])
                            //AdditionTime = Convert.ToDateTime(reader["AdditionTime"].ToString())
                        });
                    }
                }
            }
            connection.Close();
            if (discountedProducts.Count != 0) return Ok(discountedProducts);
            return NotFound();
        }

        // READY ---------->
        [HttpGet]
        public IHttpActionResult CartProducts([FromUri]int uc)
        {
            var QueryString = $"select * from User_Product up inner join ProductsTable pt on pt.ID = up.ProductID and up.UserID = @UId";

            IList<DiscountedProduct> products = new List<DiscountedProduct>();
            connection.Open();
            using(SqlCommand command = new SqlCommand(QueryString, connection))
            {
                command.Parameters.Add("@UId", SqlDbType.Int).Value = uc;
                using(SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        products.Add(new DiscountedProduct()
                        {
                            ID = Convert.ToInt32(reader["ID"]),
                            UserID = Convert.ToInt32(reader["UserID"]),
                            Name = reader["Name"].ToString(),
                            Shop = reader["Shop"].ToString(),
                            Price = Convert.ToDecimal(reader["Price"]),
                            Discount = Convert.ToDecimal(reader["Discount"]),
                            LastPrice = Convert.ToDecimal(reader["LastPrice"]),
                            // AdditionTime = Convert.ToDateTime(reader["AdditionTime"])
                        });
                    }
                }
            }
            if (products.Count == 0)
            {
                return NotFound();
            }
            return Ok(products);
        }

        // READY ---------->
        [HttpGet]
        public IHttpActionResult ShearedProducts([FromUri]int us)
        {
            var QueryString = "select * from User_SharedProduct up inner join ProductsTable pt on pt.ID = up.ProductID and up.UserID = @Us";
            IList<DiscountedProduct> products = new List<DiscountedProduct>();
            connection.Open();
            using (SqlCommand command = new SqlCommand(QueryString, connection))
            {
                command.Parameters.Add("@Us", SqlDbType.Int).Value = us;
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        products.Add(new DiscountedProduct()
                        {
                            ID = Convert.ToInt32(reader["ID"]),
                            UserID = Convert.ToInt32(reader["UserID"]),
                            Name = reader["Name"].ToString(),
                            Shop = reader["Shop"].ToString(),
                            Price = Convert.ToDecimal(reader["Price"]),
                            Discount = Convert.ToDecimal(reader["Discount"]),
                            LastPrice = Convert.ToDecimal(reader["LastPrice"]),
                            // AdditionTime = Convert.ToDateTime(reader["AdditionTime"])
                        });
                    }
                }
            }
            if (products.Count == 0)
            {
                return NotFound();
            }
            return Ok(products);            
        }

        // READY ---------->
        [HttpPost]
        public IHttpActionResult AddProduct([FromBody]DiscountedProduct p, [FromUri]int u)
        {
            var lastP = p.Price - (p.Price * p.Discount / 100);
            if (!ModelState.IsValid)
            {
                return BadRequest("\"Invalid product entry\" -Try again.");
            }
            var QueryString = "INSERT INTO ProductsTable (UserID, Name, Shop, Price, Discount, AdditionTime, LastPrice) " +
                "VALUES(@UId, @Name, @Shop, @Price, @Discount, @AdditionTime, @LastPrice)";
            
            connection.Open();

            using (SqlCommand command = new SqlCommand(QueryString, connection))
            {
                command.Parameters.Add("@UId", SqlDbType.Int).Value = u;
                command.Parameters.Add("@Name", SqlDbType.Text).Value = p.Name;
                command.Parameters.Add("@Shop", SqlDbType.Text).Value = p.Shop;
                command.Parameters.Add("@Price", SqlDbType.Decimal).Value = p.Price;
                command.Parameters.Add("@Discount", SqlDbType.Decimal).Value = p.Discount;
                command.Parameters.Add("@AdditionTime", SqlDbType.Date).Value = p.AdditionTime;
                command.Parameters.Add("@LastPrice", SqlDbType.Decimal).Value = lastP;
                if (command.ExecuteNonQuery() == 0)
                {
                    connection.Close();
                    return BadRequest("Couldn't insert product. Try again later.");
                }
            }

            connection.Close();
            return Ok();            
        }

        // READY ---------->
        [HttpPost]
        public IHttpActionResult AddToCart([FromUri]int u,[FromUri]int p)
        {
            var QueryString = "Insert into User_Product (UserID, ProductID) values(@U, @P)";

            connection.Open();
            using(SqlCommand command = new SqlCommand(QueryString, connection))
            {
                command.Parameters.Add("@U", SqlDbType.Int).Value = u;
                command.Parameters.Add("@P", SqlDbType.Int).Value = p;
                switch (command.ExecuteNonQuery())
                {
                    case 1:
                        connection.Close();
                        return Ok();
                    default:
                        connection.Close();
                        return InternalServerError();
                }
            }
        }

        // READY ---------->
        [HttpPost]
        public IHttpActionResult ShareProduct([FromUri]int u, [FromUri]int p)
        {
            var QueryString = "Insert into User_SharedProduct (UserID, ProductID) values (@U, @P)";

            connection.Open();
            using(SqlCommand command = new SqlCommand(QueryString, connection))
            {
                command.Parameters.Add("@U", SqlDbType.Int).Value = u;
                command.Parameters.Add("@P", SqlDbType.Int).Value = p;
                switch (command.ExecuteNonQuery())
                {
                    case 1:
                        connection.Close();
                        return Ok();
                    default:
                        connection.Close();
                        return InternalServerError();
                }
            }
        }

        // READY ---------->
        [HttpDelete]
        public IHttpActionResult DeleteProduct([FromUri]int Id)
        {
            var QueryString = "Delete From User_Product Where ProductID=@PID; " +
                "Delete from User_SharedProduct where ProductID=@PID;" +
                " Delete from ProductsTable where ID=@PID;";

            connection.Open();
            using(SqlCommand command = new SqlCommand(QueryString, connection))
            {
                command.Parameters.Add("@PID", SqlDbType.Int).Value = Id;
                switch (command.ExecuteNonQuery())
                {
                    case 1:
                        connection.Close();
                        return Ok($"Product with ID of {Id} deleted succesfully.");
                    default:
                        connection.Close();
                        return InternalServerError();
                }
            }
        }

        // READY ---------->
        [HttpPost]
        public IHttpActionResult UpdateProduct([FromUri]string action, [FromUri]string newParameter,[FromUri]int UpId)
        {
            if (action.Equals("name"))
            {
                var QueryString = "Update ProductsTable set Name = @NewName where ID = @Id";

                connection.Open();
                using(SqlCommand command = new SqlCommand(QueryString, connection))
                {
                    command.Parameters.Add("@NewName", SqlDbType.Text).Value = newParameter;
                    command.Parameters.Add("@Id", SqlDbType.Int).Value = UpId;

                    switch (command.ExecuteNonQuery())
                    {
                        case 1:
                            connection.Close();
                            return Ok($"Product Name changed succesfully to {newParameter}");
                        default:
                            connection.Close();
                            return InternalServerError();
                    }
                }
            }
            else if (action.Equals("shop"))
            {
                var QueryString = "Update ProductsTable set Shop = @NewShop where ID = @Id";

                connection.Open();
                using (SqlCommand command = new SqlCommand(QueryString, connection))
                {
                    command.Parameters.Add("@NewShop", SqlDbType.NChar).Value = newParameter;
                    command.Parameters.Add("@Id", SqlDbType.Int).Value = UpId;

                    switch (command.ExecuteNonQuery())
                    {
                        case 1:
                            connection.Close();
                            return Ok($"Product Shop changed succesfully to {newParameter}");
                        default:
                            connection.Close();
                            return InternalServerError();
                    }
                }
            }
            else if (action.Equals("price"))
            {
                var QueryString = "Update ProductsTable set Price = @NewPrice where ID = @Id";
                var Message = "Something went wrong!";

                connection.Open();
                using (SqlCommand command = new SqlCommand(QueryString, connection))
                {
                    command.Parameters.Add("@NewPrice", SqlDbType.Decimal).Value = Convert.ToDecimal(newParameter);
                    command.Parameters.Add("@Id", SqlDbType.Int).Value = UpId;

                    switch (command.ExecuteNonQuery())
                    {
                        case 1:
                            switch (UpdateLastPrice(UpId))
                            {
                                case true:
                                    Message = "Last Price changed succesfully.";
                                    break;
                                default:
                                    Message = "Couldn't change last price. Try Again!";
                                    break;
                            }
                            connection.Close();
                            return Ok($"Product Price changed succesfully to {newParameter}. " + Message);
                        default:
                            connection.Close();
                            return InternalServerError();
                    }
                }
            }
            else if (action.Equals("discount"))
            {
                var QueryString = "Update ProductsTable set Discount = @NewDiscount where ID = @Id";
                var Message = "Something went wrong!";
                connection.Open();
                using (SqlCommand command = new SqlCommand(QueryString, connection))
                {
                    command.Parameters.Add("@NewDiscount", SqlDbType.Decimal).Value = Convert.ToDecimal(newParameter);
                    command.Parameters.Add("@Id", SqlDbType.Int).Value = UpId;

                    switch (command.ExecuteNonQuery())
                    {
                        case 1:
                            switch (UpdateLastPrice(UpId))
                            {
                                case true:
                                    Message = "Last Price changed succesfully.";
                                    break;
                                default:
                                    Message = "Couldn't change last price. Try Again!";
                                    break;
                            }
                            connection.Close();
                            return Ok($"Product Discount changed succesfully to {newParameter}. " + Message);
                        default:
                            connection.Close();
                            return InternalServerError();
                    }
                }
            }
            else
            {
                return BadRequest("Invalid action entry. Action must be 'name', 'shop', 'price' or 'discount'.");
            }
        }

        // READY ---------->
        [NonAction]
        public bool UpdateLastPrice(int Id)
        {
            if (connection.State == ConnectionState.Closed)
                connection.Open();

            var QueryString2 = "Select Price, Discount from ProductsTable Where ID = @Id";
            decimal Price = 0, Discount = 0, LastPrice = 0;

            using (SqlCommand commannd2 = new SqlCommand(QueryString2, connection)) 
            {
                commannd2.Parameters.Add("@Id", SqlDbType.Int).Value = Id;
                using (SqlDataReader reader = commannd2.ExecuteReader()) 
                {
                    while (reader.Read())
                    {
                        Price = Convert.ToDecimal(reader["Price"]);
                        Discount = Convert.ToDecimal(reader["Discount"]);
                    }
                }
            }

            var QueryString = "Update ProductsTable Set LastPrice=@LPrice Where ID=@Id";
            LastPrice = Price * Discount / 100;

            using (SqlCommand command = new SqlCommand(QueryString, connection)) 
            {
                command.Parameters.Add("@LPrice", SqlDbType.Decimal).Value = LastPrice;
                command.Parameters.Add("@Id", SqlDbType.Int).Value = Id;
                switch (command.ExecuteNonQuery())
                {
                    case 1:
                        connection.Close();
                        return true;
                    default:
                        connection.Close();
                        return false;
                }
            }
        }
    }
}
