﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Dendi.Models
{
    public class AdProduct : Product
    {
        // Incomplete class
        public string Owner { get; set; }
        public string AdType { get; set; }
    }
}