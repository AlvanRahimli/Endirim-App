﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Dendi.Common
{
    public class LeavingReason
    {
        public string ReasonHeader { get; set; }
        public string ReasonContent { get; set; }        
    }
}