﻿using Dendi.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Dendi.Common
{
    public class LeavingUser
    {
        [Required(ErrorMessage =("Id is not specified."))]
        public int ID { get; set; }
        public LeavingReason Reason { get; set; }
        public int Stars { get; set; }
    }
}