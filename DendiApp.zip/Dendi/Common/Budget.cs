﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Dendi.Common
{
    public class Budget
    {
        public decimal Amount { get; set; }
        public string Currency { get; set; }
    }
}